#include "include.h"

extern void linije();
extern void naslov();
extern void loadingBar();
extern int brRedova();
extern void opcije();
extern void istorija();
extern void ucitajNaloge();
extern void ucitajKnjige();
extern void ucitajKorisnike();
extern void ucitajZaduzenja();
extern void login();
extern void prikaziKnjige();
extern void unesiKnjigu();
extern void obrisiKnjigu();
extern void nadjiKnjigu();
extern void prikaziKorisnika();
extern void unesiKorisnika();
extern void obrisiKorisnika();
extern void nadjiKorisnika();
extern void uplatiKorisnika();
extern void prikazZaduzenja();
extern void unesiZaduzenje();
extern void obrisiZaduzenje();
extern void prikazNaloga();
extern void unesiNalog();
extern void obrisiNalog();
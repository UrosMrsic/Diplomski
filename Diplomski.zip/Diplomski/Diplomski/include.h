#include<stdio.h>
#include <conio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
#include <windows.h>